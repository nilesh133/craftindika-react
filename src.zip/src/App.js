import React from 'react'
import "./App.css"
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Main from './components/Main/Main';

// Components import 

const App = () => {
  return (
    <Router>
      <div className='app'>
        <Routes>
          <Route path="/" exact element={<Main />} />
        </Routes>
      </div>
    </Router>
  )
}

export default App