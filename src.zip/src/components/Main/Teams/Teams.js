import React from 'react'
import "./teams.css"

const Teams = () => {

    const teamsDetails = [
        {
            profileImg:
                "https://images.unsplash.com/photo-1513956589380-bad6acb9b9d4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80",
            profileName: "Marketing Manager",
            name: "Christ Grey",
            profileDesc:
                "Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing",
        },
        {
            profileImg:
                "https://images.unsplash.com/photo-1598913870111-8c8da3f189b8?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80",
            profileName: "Graphic Designer",
            name: "Sarah Grey",
            profileDesc:
                "Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing",
        },
        {
            profileImg:
                "https://images.unsplash.com/photo-1584940120743-8981ca35b012?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80",
            profileName: "Accountant",
            name: "Jane Zhang",
            profileDesc:
                "Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing",
        },
        {
            profileImg:
                "https://images.unsplash.com/photo-1576110598658-096ae24cdb97?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80",
            profileName: "Developer",
            name: "Andrew Winson",
            profileDesc:
                "Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing",
        },
    ];

    return (
        <div className="teams">
            <div className="teams_container">
                {teamsDetails.map((team, i) => (
                    <div className="teams_details">
                        <div
                            style={{
                                flexDirection: i % 2 === 0 ? "column" : "column-reverse",
                            }}
                            className="team_content"
                        >
                            <img style={{ transform: i % 2 === 0 ? "translateY(50px)" : 'translateY(-50px)' }} src={team.profileImg} />
                            <div
                                style={{
                                    flexDirection: i % 2 === 0 ? "column" : "column-reverse",
                                }}
                                className="team_content_down"
                            >
                                <div className="team_content_arrow">
                                    <img
                                        src={
                                            i % 2 === 0
                                                ? "https://th.bing.com/th/id/R.eda8be3fce075892ebcc0ba75c720a4c?rik=dEjIkiEliX9WRA&riu=http%3a%2f%2fwww.cliparts101.com%2ffiles%2f301%2fE0DDDD06E494117674D7369F71C9005D%2farrow_down.png&ehk=yjgiXwqDmCiDGDZoBqoPXKLmw%2b1Bu6EsH%2fB%2b4Pzhxm8%3d&risl=&pid=ImgRaw&r=0"
                                                : "https://th.bing.com/th/id/R.009be86d777f1321b59467e94a0ea136?rik=VhXBrf2wledwRQ&riu=http%3a%2f%2fcliparts.co%2fcliparts%2fBia%2fABA%2fBiaABA7bT.png&ehk=26dAy%2fA7Q8F7bg6K73tzVfomNDcbPgojlYDOAR0EKQg%3d&risl=&pid=ImgRaw&r=0"
                                        }
                                    />
                                </div>
                                <h4>{team.name}</h4>
                                <p>{team.profileDesc}</p>
                            </div>
                        </div>

                    </div>
                ))}
            </div>

            <div className="teams_profilename">
                {teamsDetails.map((team) => (
                    <h3>{team.profileName}</h3>
                ))}
            </div>
        </div>

    )
}

export default Teams