import React from 'react';
import "react-responsive-carousel/lib/styles/carousel.min.css";
import { Carousel } from 'react-responsive-carousel';
import "./hero.css"

// Images import
// import intro_video from "../../videos/intro-video.mp4";
import hero_slider_image1 from "../../../images/hero-slider-image1.png";
import hero_slider_image2 from "../../../images/hero-slider-image2.png";
import hero_slider_image3 from "../../../images/hero-slider-image3.png";

const Hero = () => {
    return (
        <section className='hero'>
            <Carousel
                autoPlay
                infiniteLoop
                showStatus={false}
                showThumbs={false}
                interval={2000}
            >
                <div className='hero_slider_video'>
                    <video autoplay controls>
                        <source src="https://d2xtgt28f3klow.cloudfront.net/b21ae62faed32cc7bcffa94bed936fcb.mp4" type="video/mp4" />
                        Your browser does not support the video tag.
                    </video>
                </div>
                <div className='hero_slider_image'>
                    <img loading='lazy' src={hero_slider_image1} />
                </div>
                <div className='hero_slider_image'>
                    <img loading='lazy' src={hero_slider_image2}/>
                </div>
                <div className='hero_slider_image'>
                    <img loading='lazy' src={hero_slider_image3} />
                </div>
            </Carousel>
        </section>
    )
}

export default Hero