import React from 'react';
import "./authentication.css";

const Authentication = () => {
  return (
    <div className="authentication">
        <div className="authentication_container">
            <div className="authentication_container_box">
                <div className="authentication_container_box_left">

                </div>
                <img src = "https://images.unsplash.com/photo-1472214103451-9374bd1c798e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80"/>
            </div>
            <div className="authentication_container_box">
                <img src = "https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80"/>
                <div className="authentication_container_box_left">

                </div>
            </div>
        </div>
    </div>
  )
}

export default Authentication