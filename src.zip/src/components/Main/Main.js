import React from 'react'

// Components im
import Header from '../Header/Header'
import Navbar from '../Navbar/Navbar'
import Hero from './Hero/Hero'
import Discover from './Discover/Discover'
import Products from './Products/Products'
import Testimonials from './Testimonials/Testimonials'
import Teams from './Teams/Teams'
import Partnership from './Partnership/Partnership'
import ContactUs from './ContactUs/ContactUs'
import Authentication from './Authentication/Authentication'

const Main = () => {
  return (
    <div className='main'>
        <Header/>
        <Navbar/>
        <Hero/>
        <Discover/>
        <Products/>
        <Testimonials/>
        <Teams/>
        <Partnership/>
        <ContactUs/>
        <Authentication/>
    </div>
  )
}

export default Main