import React from 'react'
import "./navbar.css"

// Images import
import craftindika_logo from "../../images/craftindika_logo.png"

const Navbar = () => {
  return (
    <nav className='navbar'>
      <div className='navbar_left'>
        <img src = {craftindika_logo}/>
      </div>
      <div className='navbar_right'>
        <ul>
          <li>About Us</li>
          <li>E-Shop</li>
          <li>Catalogue</li>
          <li>Partnership</li>
          <li>Authentication</li>
          <li>Resources</li>
          <li>Team</li>
          <li>Contact Us</li>
        </ul>
      </div>
    </nav>
  )
}

export default Navbar