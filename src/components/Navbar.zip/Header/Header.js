import React from 'react'
import "./header.css"

// Icons import
import { AiOutlineTwitter, AiFillInstagram, AiFillLinkedin } from "react-icons/ai";
import { BsFacebook, BsPinterest } from "react-icons/bs";


const Header = () => {
    return (
        <header className="header">
            <div className='header_left'>
                <h3>Welcome to CraftIndika!</h3>
                <p>+919827894737</p>
            </div>
            <div className='header_right'>
                <span><AiOutlineTwitter /></span>
                <span><AiFillInstagram /></span>
                <span><BsFacebook /></span>
                <span><BsPinterest /></span>
                <span><AiFillLinkedin /></span>
            </div>
        </header>
    )
}

export default Header