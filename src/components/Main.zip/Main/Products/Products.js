import React from 'react'
import "./products.css"

// Icons import
import {BsArrowRight} from "react-icons/bs"

const Products = () => {
    const products = [
        {
            name: "Over the cloud sock",
            img: "https://images.unsplash.com/photo-1571781926291-c477ebfd024b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=388&q=80"
        },
        {
            name: "Over the cloud sock",
            img: "https://images.unsplash.com/photo-1491933382434-500287f9b54b?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTF8fHByb2R1Y3RzfGVufDB8MXwwfHw%3D&auto=format&fit=crop&w=500&q=60"
        },
        {
            name: "Over the cloud sock",
            img: "https://images.unsplash.com/photo-1610824352934-c10d87b700cc?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=387&q=80"
        },
        {
            name: "Over the cloud sock",
            img: "https://images.unsplash.com/photo-1617005082133-548c4dd27f35?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=464&q=80"
        },
        {
            name: "Over the cloud sock",
            img: "https://images.unsplash.com/photo-1524805444758-089113d48a6d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=388&q=80"
        },
        {
            name: "Over the cloud sock",
            img: "https://images.unsplash.com/photo-1524738258074-f8125c6a7588?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=385&q=80"
        },
    ]
  return (
    <section className='products'>
        <div className='products_container'>
            {
                products.map((product) => (
                    <div className='product'>
                        <img src={product.img}/>
                        <p>{product.name}</p>
                    </div>
                ))
            }
        </div>
        <div className='products_button'>
            <button>Shop more</button>
            <span><BsArrowRight/></span>
        </div>
    </section>
  )
}

export default Products