import React from 'react';
import "./partnership.css"

const Partnership = () => {
  return (
    <div className="partnership">
      <div className="partnerships_container">
        <div className="partnership_box">
          <div className="partnership_box_content">
            <span>01</span>
            <h3>Baby and</h3>
            <h3>Adoption</h3>
            <p>a newly baby is such</p>
            <p>a treasure. But with</p>
            <p>the cost of life</p>
            <p>spiraling</p>
            <button>LEARN MORE</button>
          </div>
        </div>
        <div className="partnership_box">
            <div className="partnership_box_content">
                <span>02</span>
                <h3>Home</h3>
                <h3>Improvement</h3>
                <p>Shower your home</p>
                <p>improvement loan</p>
                <p>the cost of life</p>
                <p>spiraling</p>
                <button>LEARN MORE</button>
            </div>
        </div>
        <div className="partnership_box">
            <div className="partnership_box_content">
                <span>03</span>
                <h3>Small</h3>
                <h3>Business</h3>
                <p>The best idea for</p>
                <p>the first tine new</p>
                <p>business and</p>
                <p>enough time</p>
                <button>LEARN MORE</button>
            </div>
        </div>
        <div className="partnership_box">
            <div className="partnership_box_content">
                <span>04</span>
                <h3>Studying</h3>
                <h3>Abroad</h3>
                <p>Student loans may</p>
                <p>be offered as part of</p>
                <p>a total package</p>
                <button>LEARN MORE</button>
            </div>
        </div>
        <div className="partnership_box">
            <div className="partnership_box_content">
                <span>04</span>
                <h3>Travels And</h3>
                <h3>Vacation</h3>
                <p>Found a trip of your</p>
                <p>dream? We can</p>
                <p>make it come true</p>
                <button>LEARN MORE</button>
            </div>
        </div>
      </div>
    </div>
  )
}

export default Partnership