import React from 'react'
import "./contactus.css"

// Icons import
import {HiOutlineMail} from "react-icons/hi";
import {ImLocation2} from "react-icons/im";
import {BiPhone} from "react-icons/bi";

const ContactUs = () => {
  return (
    <div className="contactus">
      <h3>Get in Touch</h3>
      <p>
        Lorem ipsum is placeholder text commonly used in the graphic, print, and
        publishing industries for previewing layouts
      </p>
      <div className="contactus_options_container">
        <div className="contactus_option">
            <div className="contactus_option_icon">
            <HiOutlineMail />
            </div>
            <h3>Chat to Us</h3>
            <h4>Our friendly team is here to help</h4>
            <p>hi@ourcompany.com</p>
        </div>
        <div className="contactus_option">
            <div className="contactus_option_icon">
            <ImLocation2 />
            </div>
            <h3>Office</h3>
            <h4>Our friendly team is here to help</h4>
            <p>121 Rock Street, 21 Avenue</p>
            <p>New York, NY 92103-9000</p>
        </div>
        <div className="contactus_option">
            <div className="contactus_option_icon">
            <BiPhone />
            </div>
            <h3>Phone</h3>
            <h4>Our friendly team is here to help</h4>
            <p>hi@ourcompany.com</p>
        </div>
      </div>
    </div>
  )
}

export default ContactUs