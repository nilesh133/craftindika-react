import React from 'react'
import "./discover.css"

// Icons import
import {BsArrowRight} from "react-icons/bs"

const Discover = () => {
  return (
    <section className='discover'>
        <h3>Handcrafted with love, Designed to inspire: Explore the Artisan World</h3>
        <h3>of CraftIndika</h3>
        <h4>Discover the story behind our authentic handicrafts</h4>

        <div className='discover_button'>
            <button>Read more</button>
            <span><BsArrowRight/></span>
        </div>

        <div className='discover_numbers'>
            <div className='discover_numbers_box'>
                <h4>1000+</h4>
                <h4>Product</h4>
                <h4>Variants</h4>
            </div>
            <div className='discover_numbers_box'>
                <h4>1000+</h4>
                <h4>Product</h4>
                <h4>Variants</h4>
            </div> <div className='discover_numbers_box'>
                <h4>1000+</h4>
                <h4>Product</h4>
                <h4>Variants</h4>
            </div>
        </div>
    </section>
  )
}

export default Discover