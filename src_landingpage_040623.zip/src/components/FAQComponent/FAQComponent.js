import React from 'react'
import "./faqcomponent.css";

// MUI Import
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';

const FAQComponent = ({heading}) => {
    return (
        <div className="faqcomponent">
            <div className="faqcomponent_left">
                <h3>{heading.firstLine}</h3>
                <h3>{heading.secondLine}</h3>
            </div>
            <div className='faqcomponent_right'>
                <Accordion>
                    <AccordionSummary
                        // expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel1a-content"
                        id="panel1a-header"
                    >
                        <Typography>What is CraftPartner Program? </Typography>
                    </AccordionSummary>
                    <AccordionDetails>
                        <Typography>
                            It is a prestigious partnership program designed to cater to businesses seeking exceptional, handcrafted works of art for their expansive spaces, hotel lobbies, and beyond.
                        </Typography>
                    </AccordionDetails>
                </Accordion>
                <Accordion>
                    <AccordionSummary
                        // expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel1a-content"
                        id="panel1a-header"
                    >
                        <Typography>What is the pre-requisite?</Typography>
                    </AccordionSummary>
                    <AccordionDetails>
                        <Typography>
                            It is a prestigious partnership program designed to cater to businesses seeking exceptional, handcrafted works of art for their expansive spaces, hotel lobbies, and beyond.
                        </Typography>
                    </AccordionDetails>
                </Accordion>
                <Accordion>
                    <AccordionSummary
                        // expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel1a-content"
                        id="panel1a-header"
                    >
                        <Typography>How do you ensure quality and service?</Typography>
                    </AccordionSummary>
                    <AccordionDetails>
                        <Typography>
                            It is a prestigious partnership program designed to cater to businesses seeking exceptional, handcrafted works of art for their expansive spaces, hotel lobbies, and beyond.
                        </Typography>
                    </AccordionDetails>
                </Accordion>
                <Accordion>
                    <AccordionSummary
                        // expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel1a-content"
                        id="panel1a-header"
                    >
                        <Typography>What is the pricing, do we get some discounts?</Typography>
                    </AccordionSummary>
                    <AccordionDetails>
                        <Typography>
                            It is a prestigious partnership program designed to cater to businesses seeking exceptional, handcrafted works of art for their expansive spaces, hotel lobbies, and beyond.
                        </Typography>
                    </AccordionDetails>
                </Accordion>
                <Accordion>
                    <AccordionSummary
                        // expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel1a-content"
                        id="panel1a-header"
                    >
                        <Typography>How do we get started?</Typography>
                    </AccordionSummary>
                    <AccordionDetails>
                        <Typography>
                            It is a prestigious partnership program designed to cater to businesses seeking exceptional, handcrafted works of art for their expansive spaces, hotel lobbies, and beyond.
                        </Typography>
                    </AccordionDetails>
                </Accordion>
            </div>
        </div>
    )
}

export default FAQComponent